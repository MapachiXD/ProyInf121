/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maininterfaz;

/**
 *
 * @author Omar
 */
import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class Ruta implements Serializable{
    private static final long serialVersionUID = 1L;
    private String nombre;
    private Bus[] buses;
    private int nroBuses;
    private Estacion estacion;
    
    public Ruta(){
        this.nombre="";
        this.nroBuses=0;
        this.estacion=new Estacion();
        this.buses=new Bus[100];
    }
    public void leerR(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Ingrese el nombre de la ruta: ");
        nombre=sc.next();
        System.out.println("Ingrese el numero de buses que desea insertar: ");
        int dato=sc.nextInt();
        for(int i=0;i<dato;i++){
            buses[i]=new Bus();
            buses[i].leerB();
            nroBuses++;
        }
        estacion.leerE();
    }
    public void mostrarRu(){
        System.out.println("Nombre de la ruta: "+nombre+" nroBuses: "+nroBuses);
        for(int i=0;i<nroBuses;i++){
            buses[i].mostrarB();
        }
        estacion.mostrarE();
    }
    public void agregarBuses() {
    Scanner sc = new Scanner(System.in);
    System.out.print("¿Cuántos buses desea agregar?: ");
    int cantidad = sc.nextInt();
    for (int i = 0; i < cantidad; i++) {
        if (nroBuses < buses.length) {
            buses[nroBuses] = new Bus();
            buses[nroBuses].leerB();
            nroBuses++;
        } else {
            System.out.println("Capacidad máxima de buses alcanzada.");
            break;
        }
    }
}
public void mostrarBusMayorCapacidad() {
    if (nroBuses == 0) {
        System.out.println("No hay buses registrados en esta ruta.");
        return;
    }

    Bus mayor = buses[0];
    for (int i = 1; i < nroBuses; i++) {
        if (buses[i].getCapacidad() > mayor.getCapacidad()) {
            mayor = buses[i];
        }
    }

    System.out.println("🚌 Bus con mayor capacidad en la ruta '" + nombre + "':");
    mayor.mostrarB();
}
public int obtenerAnioBusMasReciente() {
    if (nroBuses == 0) return -1;

    int maxAnio = buses[0].getAnio();
    for (int i = 1; i < nroBuses; i++) {
        if (buses[i].getAnio() > maxAnio) {
            maxAnio = buses[i].getAnio();
        }
    }
    return maxAnio;
}
public Bus obtenerBusMayorCapacidad() {
    if (nroBuses == 0) return null;

    Bus mayor = buses[0];
    for (int i = 1; i < nroBuses; i++) {
        if (buses[i].getCapacidad() > mayor.getCapacidad()) {
            mayor = buses[i];
        }
    }
    return mayor;
}
public void mostrarH() {
    System.out.println("Nombre de la ruta: " + nombre + " nroBuses: " + nroBuses);
    for (int i = 0; i < nroBuses; i++) {
        buses[i].mostrarB();
        buses[i].mostrarDuracionViaje(); // Agregado
    }
    estacion.mostrarE();
}

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Bus[] getBuses() {
        return buses;
    }

    public void setBuses(Bus[] buses) {
        this.buses = buses;
    }

    public int getNroBuses() {
        return nroBuses;
    }

    public void setNroBuses(int nroBuses) {
        this.nroBuses = nroBuses;
    }

    public Estacion getEstacion() {
        return estacion;
    }

    public void setEstacion(Estacion estacion) {
        this.estacion = estacion;
    }
    
}
