/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maininterfaz;

/**
 *
 * @author Omar
 */
import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class Horario implements Serializable {
     private double horaSalida;
    private double horaLlegada;
    
    public Horario(){
        this.horaSalida=0;
        this.horaLlegada=0;
    }
    public Horario(double hS,double hL){
        this.horaSalida=hS;
        this.horaLlegada=hL;
    }
    public void leerH(){
        Scanner lee=new Scanner(System.in);
        System.out.println("Ingrese el horario de Salida");
        horaSalida=lee.nextDouble();
        System.out.println("Ingrese la hora de llegada");
        horaLlegada=lee.nextDouble();
    }
    public void mostrarH(){
        System.out.println("Hora Salida: "+horaSalida+" Hora Llegada: "+horaLlegada);
    }
public double calcularDuracion() {
    double duracion = horaLlegada - horaSalida;
    if (duracion < 0) {
        duracion += 24; // Considerar que pasó la medianoche
    }
    return duracion;
}

    public double getHoraSalida() {
        return horaSalida;
    }

    public void setHoraSalida(double horaSalida) {
        this.horaSalida = horaSalida;
    }

    public double getHoraLlegada() {
        return horaLlegada;
    }

    public void setHoraLlegada(double horaLlegada) {
        this.horaLlegada = horaLlegada;
    }
}

