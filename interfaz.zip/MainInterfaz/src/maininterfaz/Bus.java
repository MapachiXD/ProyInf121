/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maininterfaz;

/**
 *
 * @author Omar
 */
import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class Bus extends Auto implements Serializable{
    private int capacidad;
    private int anio;
    private Horario horario;
    
    public Bus(){
        super();
        this.capacidad=0;
        this.anio=0;
        this.horario=new Horario();
    }
    public Bus(String marca,String placa,int capacidad,int anio,Horario h){
        super(marca,placa);
        this.capacidad=capacidad;
        this.anio=anio;
        this.horario=h;
    }
    public void leerB(){
        Scanner lee=new Scanner(System.in);
        System.out.println("Ingrese los datos del bus");
        super.leerA();
        System.out.println("Ingrese la capacidad");
        capacidad=lee.nextInt();
        System.out.println("Ingrese el Anio");
        anio=lee.nextInt();
        horario.leerH();
        
    }
    public void mostrarB(){
        System.out.println("Mostrando el bus");
        super.mostrarA();
        System.out.println("Capacidad: "+capacidad+" Anio: "+anio);
        horario.mostrarH();
    }
    public void mostrarDuracionViaje() {
    double duracion = horario.calcularDuracion();
    System.out.println("Duración del viaje: " + duracion + " horas");
}

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public Horario getHorario() {
        return horario;
    }

    public void setHorario(Horario horario) {
        this.horario = horario;
    }
}
