/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package maininterfaz;

import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class Auto implements Serializable{
    protected String marca;
    protected String placa;
    
    public Auto(){
        this.marca="";
        this.placa="";
    }
    public Auto(String marca,String placa){
        this.marca=marca;
        this.placa=placa;
    }
    public void leerA(){
        Scanner lee=new Scanner(System.in);
        System.out.println("Ingrese la marca");
        marca=lee.next();
        System.out.println("Ingrese la placa");
        placa=lee.next();
        
    }
    public void mostrarA(){
        System.out.println("Marca: "+marca+" Placa: "+placa);
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
    
}
