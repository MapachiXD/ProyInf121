/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.red12;

import java.io.IOException;
import java.util.Scanner;

/**
 *mostrar el nombre de la estacion de la ruta x leida por teclado
 * mostrar cual de los buses tiene mayor capacidad de la ruta x
 * comparar 2 rutas y mostrar el año mas reciente de sus buses
 * mostrar al bus con mayor capacidad de pasajeros de 2 rutas
 * calcula cuantas horas le toma a un bus llegar a su destino
 * 
 * @author Omar
 */
public class Red12 {

    public static void main(String[] args) throws IOException {
        RedTransporte r1=new RedTransporte();
        Scanner sc=new Scanner(System.in);
        int opcion;
        String archivo="rutas.dat";
        do {
            System.out.println("\n Menú del Sistema de Registro");
            System.out.println("1. Agregar Ruta");
            System.out.println("2. Mostrar Rutas");
            System.out.println("3. Guardar en archivo");
            System.out.println("4. Cargar desde archivo");
            System.out.println("5. Mostrar estación de la ruta por nombre");
            System.out.println("6. Añadir más buses a una ruta");
            System.out.println("7. Mostrar bus con mayor capacidad de una ruta");
            System.out.println("8. Comparar dos rutas por año más reciente de sus buses");
            System.out.println("9. Comparar bus con mayor capacidad entre 2 rutas");
            System.out.println("10. Mostrar duración de viaje de cada bus");
            System.out.println("0. Salir");
            System.out.print("Opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer
            switch (opcion) {
                case 1:
                    r1.agregarRutas();
                    System.out.println("Ruta guardada correctamente");
                    break;
                case 2:
                    System.out.println("PUMA KATARI");
                    r1.mostrarRutas();

                    break;
                case 3:
                    r1.guardarArchivo(archivo);

                    break;
                case 4:
                    r1.cargarArchivo(archivo);
                    break;
                case 5:
                    r1.mostrarEstacionDeRutaX();
                    break;
                case 6:
                    r1.agregarBusesARuta();
                    break;
                case 7:
                    r1.mostrarBusMayorCapacidadEnRuta();
                    break;
                case 8:
                    r1.compararRutasPorAnioBusMasReciente();
                    break;
                case 9:
                    r1.compararBusMayorCapacidadDeDosRutas();
                    break;
                case 10:
                    for (int i = 0; i < r1.getNroRutas(); i++) {
                        Ruta ruta = r1.getRutas()[i];
                        System.out.println("Ruta: " + ruta.getNombre());
                        Bus[] buses = ruta.getBuses();
                        for (int j = 0; j < ruta.getNroBuses(); j++) {
                            System.out.println("Bus " + (j + 1) + ":");
                            buses[j].mostrarDuracionViaje();
                        }
                    }
                    break;

                case 0:
                    System.out.println("👋 ¡Hasta luego!");
                    break;
                default:
                    System.out.println("❌ Opción inválida");
            }
        } while (opcion != 0);

    }
}
