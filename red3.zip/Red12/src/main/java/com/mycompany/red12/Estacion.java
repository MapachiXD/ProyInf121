/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.red12;

import java.io.Serializable;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class Estacion implements Serializable{
    private String nombre;
    
    public Estacion(){
        this.nombre=nombre;
    }
    public Estacion(String nombre){
        this.nombre=nombre;
    }
    public void leerE(){
        Scanner lee=new Scanner(System.in);
        System.out.println("Ingrese el nombre de la estacion: ");
        nombre=lee.next();
    }
    public void mostrarE(){
        System.out.println("Estacion ");
        System.out.println("Nombre: "+nombre);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}
