/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.red12;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

/**
 *
 * @author Omar
 */
public class RedTransporte {
    private Ruta[] rutas;
    private int nroRutas;
    public RedTransporte(){
        rutas=new Ruta[100];
        nroRutas=0;
    }
    public void agregarRutas(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Ingrese el numero de rutas que desea añadir");
        int dato=sc.nextInt();
        for(int i=0;i<dato;i++){
        rutas[nroRutas] = new Ruta();
        rutas[nroRutas].leerR();
        nroRutas++;
        }
    }
    public void mostrarRutas(){
        if (nroRutas == 0) {
        System.out.println("No hay rutas registradas");
        return;
    }

    System.out.println("Las rutas son:");
    for (int i = 0; i < nroRutas; i++) {
        if (rutas[i] != null) {
            rutas[i].mostrarRu();
        } else {
            System.out.println("Ruta vacía en posición " + i);
        }
    }
    }
    public void guardarArchivo(String nombreArchivo) throws FileNotFoundException, IOException{
        try(ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(nombreArchivo))){
            oos.writeInt(nroRutas);
            oos.writeObject(rutas); 
           System.out.println("Rutas guardadas correctamente");
        }catch (IOException e) {
            System.out.println("Error al guardar: " +e.getMessage());}
    }
    @SuppressWarnings("unchecked")
    public void cargarArchivo(String nombreArchivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(nombreArchivo))) {
            nroRutas = ois.readInt(); 
            rutas = (Ruta[]) ois.readObject();
            System.out.println("Rutas cargados correctamente.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error al cargar: " +e.getMessage());
        }
    }
    public void mostrarEstacionDeRutaX() {
    if (nroRutas == 0) {
        System.out.println("No hay rutas registradas.");
        return;
    }

    Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese el nombre de la ruta a buscar: ");
    String nombreBuscado = sc.next();

    boolean encontrado = false;
    for (int i = 0; i < nroRutas; i++) {
        if (rutas[i] != null && rutas[i].getNombre().equalsIgnoreCase(nombreBuscado)) {
            System.out.println("Nombre de la estación: " + rutas[i].getEstacion().getNombre());
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        System.out.println("No se encontró una ruta con ese nombre.");
    }
    }
    public void agregarBusesARuta() {
    if (nroRutas == 0) {
        System.out.println("No hay rutas registradas.");
        return;
    }

    Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese el nombre de la ruta a la que desea añadir buses: ");
    String nombreRuta = sc.next();

    boolean encontrado = false;
    for (int i = 0; i < nroRutas; i++) {
        if (rutas[i] != null && rutas[i].getNombre().equalsIgnoreCase(nombreRuta)) {
            rutas[i].agregarBuses();
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        System.out.println("Ruta no encontrada.");
    }
}
public void mostrarBusMayorCapacidadEnRuta() {
    if (nroRutas == 0) {
        System.out.println("No hay rutas registradas.");
        return;
    }

    Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese el nombre de la ruta: ");
    String nombreRuta = sc.next();

    boolean encontrado = false;
    for (int i = 0; i < nroRutas; i++) {
        if (rutas[i] != null && rutas[i].getNombre().equalsIgnoreCase(nombreRuta)) {
            rutas[i].mostrarBusMayorCapacidad();
            encontrado = true;
            break;
        }
    }

    if (!encontrado) {
        System.out.println(" Ruta no encontrada.");
    }
}
public void compararRutasPorAnioBusMasReciente() {
    if (nroRutas < 2) {
        System.out.println("Se necesitan al menos 2 rutas para comparar.");
        return;
    }

    Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese el nombre de la primera ruta: ");
    String nombre1 = sc.next();
    System.out.print("Ingrese el nombre de la segunda ruta: ");
    String nombre2 = sc.next();

    Ruta ruta1 = null;
    Ruta ruta2 = null;

    for (int i = 0; i < nroRutas; i++) {
        if (rutas[i].getNombre().equalsIgnoreCase(nombre1)) {
            ruta1 = rutas[i];
        }
        if (rutas[i].getNombre().equalsIgnoreCase(nombre2)) {
            ruta2 = rutas[i];
        }
    }

    if (ruta1 == null || ruta2 == null) {
        System.out.println(" Una o ambas rutas no existen.");
        return;
    }

    int anio1 = ruta1.obtenerAnioBusMasReciente();
    int anio2 = ruta2.obtenerAnioBusMasReciente();

    if (anio1 == -1 || anio2 == -1) {
        System.out.println("Una de las rutas no tiene buses.");
        return;
    }

    System.out.println("? Comparación de años más recientes:");
    System.out.println(ruta1.getNombre() + ": Año más reciente = " + anio1);
    System.out.println(ruta2.getNombre() + ": Año más reciente = " + anio2);

    if (anio1 > anio2) {
        System.out.println("➡️ " + ruta1.getNombre() + " tiene el bus más reciente.");
    } else if (anio2 > anio1) {
        System.out.println("️ " + ruta2.getNombre() + " tiene el bus más reciente.");
    } else {
        System.out.println(" Ambas rutas tienen buses con el mismo año más reciente: " + anio1);
    }
}
public void compararBusMayorCapacidadDeDosRutas() {
    if (nroRutas < 2) {
        System.out.println("Se necesitan al menos 2 rutas para comparar.");
        return;
    }

    Scanner sc = new Scanner(System.in);
    System.out.print("Ingrese el nombre de la primera ruta: ");
    String nombre1 = sc.next();
    System.out.print("Ingrese el nombre de la segunda ruta: ");
    String nombre2 = sc.next();

    Ruta ruta1 = null;
    Ruta ruta2 = null;

    for (int i = 0; i < nroRutas; i++) {
        if (rutas[i].getNombre().equalsIgnoreCase(nombre1)) {
            ruta1 = rutas[i];
        }
        if (rutas[i].getNombre().equalsIgnoreCase(nombre2)) {
            ruta2 = rutas[i];
        }
    }

    if (ruta1 == null || ruta2 == null) {
        System.out.println(" Una o ambas rutas no existen.");
        return;
    }

    Bus bus1 = ruta1.obtenerBusMayorCapacidad();
    Bus bus2 = ruta2.obtenerBusMayorCapacidad();

    if (bus1 == null || bus2 == null) {
        System.out.println("Una de las rutas no tiene buses.");
        return;
    }

    System.out.println(" Bus con mayor capacidad en " + ruta1.getNombre() + ":");
    bus1.mostrarB();
    System.out.println("Bus con mayor capacidad en " + ruta2.getNombre() + ":");
    bus2.mostrarB();

    if (bus1.getCapacidad() > bus2.getCapacidad()) {
        System.out.println("️ El bus de mayor capacidad pertenece a la ruta " + ruta1.getNombre());
    } else if (bus2.getCapacidad() > bus1.getCapacidad()) {
        System.out.println("️ El bus de mayor capacidad pertenece a la ruta " + ruta2.getNombre());
    } else {
        System.out.println(" Ambos buses tienen la misma capacidad de pasajeros.");
    }
}


    public Ruta[] getRutas() {
        return rutas;
    }

    public void setRutas(Ruta[] rutas) {
        this.rutas = rutas;
    }

    public int getNroRutas() {
        return nroRutas;
    }

    public void setNroRutas(int nroRutas) {
        this.nroRutas = nroRutas;
    }

}
