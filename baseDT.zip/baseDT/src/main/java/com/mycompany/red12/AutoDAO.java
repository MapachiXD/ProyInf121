/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.red12;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author Abran
 */
public class AutoDAO {
     public void guardar(Auto auto) {
        Connection conn = ConexionBD.conectar();

        if (conn != null) {
            try {
                String sql = "INSERT INTO autos (marca, placa) VALUES (?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, auto.getMarca());
                stmt.setString(2, auto.getPlaca());

                stmt.executeUpdate();
                System.out.println(" Auto guardado correctamente en la base de datos.");
                System.out.println("Se guardo el Auto de marca: "+auto.getMarca()+ " Con placa: " +auto.getPlaca());
                conn.close();
            } catch (SQLException e) {
                System.out.println("Error al guardar auto: " + e.getMessage());
            }
        } else {
            System.out.println("No se pudo conectar a la base de datos.");
        }
    }
}
